﻿namespace cats_shop
{
    public class cat
    {
        public string breed {  get; set; }
        public string gender { get; set; }
        public string colour { get; set; }
        public int age { get; set; }
    }
}
